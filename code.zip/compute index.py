import pandas as  pd
import numpy as np
from sklearn.metrics.cluster import normalized_mutual_info_score

path = "pred_label.csv"
t = pd.read_csv("C:\\Users\\wangjing\\Desktop\\test\\camp2_truelabel.csv",index_col=0,header=0)
name =path.split("/")[-1].split("_")[0]
#data =pd.read_csv(path,index_col=0,header=0)
data =pd.read_csv(path,header=None)
print(name)

pred_label = np.array(data.iloc[:,0])
true_label = np.array(t.iloc[:,0])
print(len(pred_label),len(true_label))

from sklearn.metrics.cluster import normalized_mutual_info_score
NMI = normalized_mutual_info_score(true_label,pred_label)
print("NMI:",NMI)
from sklearn.metrics.cluster import adjusted_rand_score
ARI = adjusted_rand_score(true_label,pred_label)
print("ARI:",ARI)
from sklearn.metrics.cluster import homogeneity_score
HOMO = homogeneity_score(true_label,pred_label)
print("HOMO:",HOMO)
from sklearn.metrics.cluster import completeness_score
COMP = completeness_score(true_label,pred_label)
print("COMP:",COMP)