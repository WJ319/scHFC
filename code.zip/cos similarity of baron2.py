import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

biao=0.9
jiange=25

data= pd.read_csv("C:\\Users\\lin\\Desktop\\data1\\2000高变\\baron2_2000.csv",header=None)
data=np.array(data).T


#data= pd.read_csv("C:\\Users\\lin\\Desktop\\data\\baron2\\baron2_log.csv",index_col=0, header=0)
#data =np.array(data)
cu= pd.read_csv("D:\\QQ\\724166365\\FileRecv\\baron2_lvshudu_N=8.txt",header=None,sep="\t")
cu= np.array(cu)

for i in range(cu.shape[1]):  # 列号

    j = cu[:, i]  # 每一列
    max9 = np.argwhere(j >= biao)
    max9 = max9.reshape(max9.shape[0], )
    print(">%.2f细胞数所在的列：%d" % (biao, i + 1))
    print(">%.2f细胞数：%d"%(biao,len(max9)))
    datamax9 =data[:,max9]
    datamaxave = np.average(datamax9 , axis=1)
    len11 =0
    list=np.array([]).astype(float)
    #for ii in range(0,100,jiange):
    xiao =0
    da = 0.3
    min = np.argwhere((j >= xiao) & (j < da))
    min = min.reshape(min.shape[0], )
    if len(min)==0:
        print("%.2f-%.2f距离平均:%f,细胞个数:%d" % (xiao, da, 0, 0))
        #continue
    else:
        datamin =data[:,min]
        distmax = 0
        s = np.corrcoef(datamax9.T, datamin.T)
        for qq in range(datamin.shape[1]):
            jj = datamin[:,qq]
            #distmax = distmax + np.linalg.norm(jj - datamaxave)
            distmax = distmax + cosine_similarity(jj.reshape(1, -1) , datamaxave.reshape(1, -1) ).reshape(1)

        ave =distmax / datamin.shape[1]

        list =np.append(list,ave)

        print("%.2f-%.2f距离平均:%f,细胞个数%d" % (xiao,da,ave,len(min)))
        len11=len11+len(min)

    xiao = 0.3
    da = 0.7
    min = np.argwhere((j >= xiao) & (j < da))
    min = min.reshape(min.shape[0], )
    if len(min) == 0:
        print("%.2f-%.2f距离平均:%f,细胞个数:%d" % (xiao, da, 0, 0))
        #continue
    else:
        datamin = data[:, min]
        distmax = 0
        s = np.corrcoef(datamax9.T, datamin.T)
        for qq in range(datamin.shape[1]):
            jj = datamin[:, qq]
            # distmax = distmax + np.linalg.norm(jj - datamaxave)
            distmax = distmax + cosine_similarity(jj.reshape(1, -1) , datamaxave.reshape(1, -1) ).reshape(1)

        ave = distmax / datamin.shape[1]

        list = np.append(list, ave)

        print("%.2f-%.2f距离平均:%f,细胞个数%d" % (xiao, da, ave, len(min)))
        len11 = len11 + len(min)

    xiao = 0.7
    da = 1
    min = np.argwhere((j >= xiao) & (j <= da))
    min = min.reshape(min.shape[0], )
    if len(min) == 0:
        print("%.2f-%.2f距离平均:%f,细胞个数:%d" % (xiao, da, 0, 0))
        #continue
    else:
        datamin = data[:, min]
        distmax = 0
        s = np.corrcoef(datamax9.T, datamin.T)
        for qq in range(datamin.shape[1]):
            jj = datamin[:, qq]
            # distmax = distmax + np.linalg.norm(jj - datamaxave)
            distmax = distmax + cosine_similarity(jj.reshape(1, -1) , datamaxave.reshape(1, -1) ).reshape(1)

        ave = distmax / datamin.shape[1]

        list = np.append(list, ave)

        print("%.2f-%.2f距离平均:%f,细胞个数%d" % (xiao, da, ave, len(min)))
        len11 = len11 + len(min)



    #list = list/ np.sum(list)
    #print(np.sum(list))
    #list = np.exp(-7*list)
    #list = (list - np.mean(list)) / np.std(list)
    print(list)
    #print(np.sum(list))
    #list = np.exp(-list)
    #list = list/np.sum(list)
    #print(list)
    #print(np.sum(list))
    print(len11)
    print("----------------------------------------")
