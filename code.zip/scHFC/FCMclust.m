function result = FCMclust(data,param)
X=data.X;
f0=param.c;
if exist('param.m')==1, m = param.m;else m = 2;end;
if exist('param.e')==1, e = param.m;else e = 1e-4;end;
[N,n] = size(X);
[Nf0,nf0] = size(f0); 
X1 = ones(N,1);
%rng('default')
%rng(sum(100*clock),'v4')
rng('shuffle')
rng(mod(floor(now*8640000),2^31-1),'twister')
if max(Nf0,nf0) == 1, 		
  c = f0;
  mm = mean(X);             
  aa = max(abs(X - ones(N,1)*mm)); 
  v = 2*(ones(c,1)*aa).*(rand(c,n)-0.5) + ones(c,1)*mm;
  for j = 1 : c,
    xv = X - X1*v(j,:);
    d(:,j) = sum((xv*eye(n).*xv),2);
  end;
  d = (d+1e-10).^(-1/(m-1));
  f0 = (d ./ (sum(d,2)*ones(1,c)));
 else
  c = size(f0,2);
  fm = f0.^m; sumf = sum(fm);
  v = (fm'*X)./(sumf'*ones(1,n)); %
end;
f = zeros(N,c);                
iter = 0;                      
while  max(max(f0-f)) > e
  iter = iter + 1;
  f = f0;
  fm = f.^m;
  sumf = sum(fm);
  v = (fm'*X)./(sumf'*ones(1,n));
  for j = 1 : c,
    xv = X - X1*v(j,:);
    d(:,j) = sum((xv*eye(n).*xv),2);
  end;
  distout=sqrt(d);
  J(iter) = sum(sum(f0.*d));
  % Update f0
  d = (d+1e-10).^(-1/(m-1));
  f0 = (d ./ (sum(d,2)*ones(1,c)));
end
fm = f.^m; 
sumf = sum(fm);
%results
result.data.f=f0;
result.data.d=distout;
result.cluster.v=v;
result.iter = iter;
result.cost = J;