function [ center,U,v] = SAGAfun( m,cln,lb,ub,X,options)
%
%  
  data.X=X;
   cn=cln;
   q =0.8;     
   T0=100;   
   Tend=99.999;  
   sizepop=10;              
   MAXGEN=100;    
   NVAR=m*cn ;   
   PRECI=12;             
   pc=0.7;
   pm=0.01;
   trace=zeros(NVAR+1,MAXGEN);
   FieldD=[rep([PRECI],[1,NVAR]);rep([lb;ub],[1,cn]);rep([1;0;1;1],[1,NVAR])];
   Chrom=crtbp(sizepop, NVAR*PRECI);
   V=bs2rv(Chrom, FieldD);
   objV=objfun(X,cn,V,options);
    T=T0;
   while T>Tend
         gen=0;                                              
       while gen<MAXGEN                                     
             FitnV=ranking(objV);                         
             SelCh=select('sus', Chrom, FitnV);         
             SelCh=recombin('xovsp', SelCh,pc);             
             SelCh=mut(SelCh,pm);                              
             V=bs2rv(SelCh, FieldD);
             newObjV=objfun(data.X,cn,V,options);  
             newChrom=SelCh;
            
          for i=1:sizepop
               if objV(i)>newObjV(i)
                   objV(i)=newObjV(i);
                   Chrom(i,:)=newChrom(i,:);
               else
                   p=rand;
                   if p<=exp((newObjV(i)-objV(i))/T)
                       objV(i)=newObjV(i);
                       Chrom(i,:)=newChrom(i,:);
                   end
               end
           end
           gen=gen+1;                                                 
           [trace(end,gen),index]=min(objV);                        
           trace(1:NVAR,gen)=V(index,:);
          fprintf(1,'%d ',gen);
       end
       T=T*q;
      
   end
       int_V=[trace(1:NVAR,end)]';     
           [sizepop,m]=size(int_V); 
           ch=m/cln;                
           v=reshape(int_V(1,:),cn,ch); 
[newObjV,center,U]=objfun(X,cn,[trace(1:NVAR,end)]',options);  
U=U{1};
center=center{1};


end

