function U=initFCM(X,cluster_n,center,b)
dist=distfcm(center,X);      
tmp=dist.^(-2/(b-1));
U=tmp./(ones(cluster_n,1)*sum(tmp));