function [U_new,center,obj_fcn]=iterateFCM(X,U,cluster_n,b)
mf=U.^b;       
center=mf*X./((ones(size(X,2),1)*sum(mf'))'); 
dist=distfcm(center,X);       
obj_fcn=sum(sum((dist.^2).*mf)); 
tmp=dist.^(-2/(b-1));
U_new=tmp./(ones(cluster_n,1)*sum(tmp));
