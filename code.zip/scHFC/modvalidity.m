function result = modvalidity(result,data,param)

N = size(result.data.f,1);
c = size(result.cluster.v,1);
n = size(result.cluster.v,2);
v = result.cluster.v;
if exist('param.m')==1, m = param.m;else m = 2;end;
fm = (result.data.f).^m;
PC = 1/N*sum(sum(fm));  
result.validity.PC = PC;
ni = sum(result.data.f);                       
si = sum(result.data.d.*result.data.f.^(m/2));  
pii=si./ni;
mask = zeros(c,n,c);                           
for i = 1:c
    for j =1:c
         mask(j,:,i) = v(i,:);
    end
    dist(i) = sum(sum((mask(:,:,i) - v).^2));
end
s = dist;
SC = sum(pii./s);
S = sum(pii)./(N*min(dist));
XB = sum((sum(result.data.d.*result.data.f.^2))./(N*min(result.data.d)));
result.validity.SC = SC;
result.validity.S = S;
result.validity.XB = XB;    
        
        
        

