close all
clear all

tic
data_select='Baron2';
switch data_select
     case 'Baron2'
         load baron2_logcounts_genefilt.txt
         load baron2_lable.txt
         True_lab=baron2_lable;
         input_Seq=baron2_logcounts_genefilt;   
         dr_dims=5;
 end   
mappeA = compute_mapping(input_Seq,'PCA',dr_dims);
data= mappeA(:,1:end);
data.X=data;
[N,n]=size(data.X);
data = clust_normalize(data,'range');
X=data.X;
ncmax=fix(log2(N)); 
SAGA_Start=1;
param.m=2;
param.e=1e-6;
for cln=2:ncmax
    param.c=cln;
    param.ro = ones(1,param.c);
if SAGA_Start
    m=size(X,2);
    lb=min(X);
    ub=max(X);
    options=[param.m,200,param.e];
    cn=cln;
   [~,U]=SAGAfun(m,cln,lb,ub,X,options);
   param.c=U';
end
    result=FCMclust(data,param);
    new.X=data.X;
    clusteval(new,result,param)
    result=modvalidity(result,data,param);
    ment{cln}=result.validity;  
   end   
PC=[];SC=[];S=[];XB=[];
    for i=2:ncmax
       PC=[PC ment{i}.PC];
       SC=[SC ment{i}.SC];
       S=[S ment{i}.S];
       XB=[XB ment{i}.XB];              
    end
Ncmaxrow=ncmax;
PC=PC(:,1:Ncmaxrow-1);
SC=SC(:,1:Ncmaxrow-1);
S=S(:,1:Ncmaxrow-1);
XB=XB(:,1:Ncmaxrow-1);

[PC_sort,PC_index]=sort(PC,2,'descend');
PC_n=PC_index+1;
[SC_sort,SC_index]=sort(SC,2,'ascend');  
SC_n=SC_index+1;
[S_sort,S_index]=sort(S,2,'ascend');  
S_n=S_index+1;
[XB_sort,XB_index]=sort(XB,2,'ascend');  
XB_n=XB_index+1;
optPCSCSXB=[PC_n',SC_n',S_n',XB_n'];

for i=1:ncmax
    optPBsorting=optPCSCSXB(1:i,:);
    tb1=tabulate(optPBsorting(:));
   [clust,row]=find(tb1(:,2)==4);
   tt=isempty(clust);
   if tt==0;
       optclust=clust;
   break
   end
 end     
    optclust=max(optclust);
    param.c=optclust;
    param.ro = ones(1,param.c);
      if SAGA_Start
       [~,U,v]=SAGAfun(m,optclust,lb,ub,X,options);
       param.c=U';
    end
       result=FCMclust(data,param);
       param.c=result.data.f;
       result=GGclust(data,param);    
    [maxnum,ind]=max(result.data.f,[],2);
    dlmwrite('Baron2_clustlabels.txt',ind,'delimiter','\t');
       
    fprintf(1,'\n optclust number=:%d\n',optclust);
    figure(1)
    clf
    subplot(4,1,1), plot([2:ncmax],PC,'r')
    title('Partition Coefficient (PC)')
    axis tight
    subplot(4,1,2), plot([2:ncmax],SC,'g')
    title('Partition Index (SC)')
    axis tight
    subplot(4,1,3), plot([2:ncmax],XB)
    title('Xie and Beni Index (XB)')
    axis tight
    subplot(4,1,4), plot([2:ncmax],S,'m')
    title('Separation Index (S)')
    axis tight      
    mytimer1=toc;
    disp(mytimer1)
  