import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
plt.figure(dpi=300,figsize=(5,5))#####不带图例
#plt.figure(dpi=300,figsize=(10.5,5))####带图例
plt.rcParams['font.family'] = 'Times New Roman' # 设置字体样式
plt.rcParams['xtick.labelsize']= 32
plt.rcParams['ytick.labelsize']= 32
plt.xlim((-25, 25))
plt.ylim((-25, 25))


data = pd.read_csv("E:\\my scdata\\original_data_locounts\\csv\\deng_logcounts.csv",index_col=0,header=0)
data = pd.DataFrame(data)
data=data.T

#true_label = pd.read_csv("E:\\my scdata\\truelabel\\darmanis_truelabel.csv",index_col=0,header=0)
#true_label=np.array(true_label)
#true_label = true_label.ravel()

pred_label = pd.read_csv("E:\\FG paper\\112日大修\\实验\\Q1-1\\可视化标签goolam\\deng_scGAMI051.txt",header=None)
pred_label=np.array(pred_label)
pred_label = pred_label.ravel()

#r1 = pd.Series(pred_label).value_counts()#统计预测各类别的数目
#r2 = pd.Series(true_label).value_counts()#统计真实各类别的数目
r = pd.concat([pd.Series(pred_label, index = data.index), data ], axis = 1)
r.columns = [u'label'] + list(data.columns)
print(data.columns)
#print(r.columns)

tsne = TSNE( )
tsne.fit_transform(data)
a = pd.DataFrame(tsne.embedding_, index = data.index)


plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


d = a[r[u'label'] == 1]
plt.scatter(d[0], d[1], c='r',marker='.',label="1")
d = a[r[u'label'] == 2]
plt.scatter(d[0], d[1], c='g',marker='.',label="2")
d = a[r[u'label'] == 3]
plt.scatter(d[0], d[1], c='y',marker='.',label="3")
d = a[r[u'label'] == 4]
plt.scatter(d[0], d[1], c='b',marker='.',label="4")
d = a[r[u'label'] == 5]
plt.scatter(d[0], d[1], c='k',marker='.',label="5")
d = a[r[u'label'] == 6]
plt.scatter(d[0], d[1], c='m',marker='.',label="6")
d = a[r[u'label'] == 7]
plt.scatter(d[0], d[1], c='c',marker='.',label="7")
d = a[r[u'label'] == 8]
plt.scatter(d[0], d[1], c='#808080',marker='.',label="8")
d = a[r[u'label'] == 9]
plt.scatter(d[0], d[1], c='#DDA0DD',marker='.',label="9")

d = a[r[u'label'] == 10]
plt.scatter(d[0], d[1], c='#FF8C00',marker='.',label="10")
d = a[r[u'label'] == 11]
plt.scatter(d[0], d[1], c='#00BFFF',marker='.',label="11")
d = a[r[u'label'] == 12]
plt.scatter(d[0], d[1], c='#800000',marker='.',label="12")
d = a[r[u'label'] == 13]
plt.scatter(d[0], d[1], c='#7CFC00',marker='.',label="13")
d = a[r[u'label'] == 14]
plt.scatter(d[0], d[1], c='#800080',marker='.',label="14")
d = a[r[u'label'] == 15]
plt.scatter(d[0], d[1], c='#FF00FF',marker='.',label="15")
d = a[r[u'label'] == 16]
plt.scatter(d[0], d[1], c='#40E0D0',marker='.',label="16")
d = a[r[u'label'] == 17]
plt.scatter(d[0], d[1], c='#006400',marker='.',label="17")
d = a[r[u'label'] == 18]
plt.scatter(d[0], d[1], c='#FFD700',marker='.',label="18")
d = a[r[u'label'] == 19]
plt.scatter(d[0], d[1], c='#FF4500',marker='.',label="19")



plt.xlabel("tSNE1",fontsize = 32)
plt.ylabel("tSNE2",fontsize = 32)
#plt.xticks(fontsize=15)
#plt.yticks(fontsize=15)
#plt.legend(bbox_to_anchor=(1.1,1.0),ncol=3,loc=2, borderaxespad=0,fontsize=24)
plt.title('scGMAI',fontsize=36,fontweight= 'black')
plt.savefig("E:\\FG paper\\112日大修\\论文修改\\图\\deng_scgmai.jpg")
plt.tight_layout()
plt.show()
#plt.savefig("E:\\FG paper\\myplot\\SNN-Cliq.png")